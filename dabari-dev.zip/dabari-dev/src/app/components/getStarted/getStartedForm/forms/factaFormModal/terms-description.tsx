import React from 'react'

export default function TermsDescription() {
    return (
        <div className='space-y-7'>
            <p className='font-bold'>{'If you have answered "Yes" to any of the above questions, please complete the requested additional details on Section B'}</p>

            <p className='font-bold'>I, acknowledge and declare under the penalties of perjury that the information provided on Form A and Form B (where applicable) is correct and true and complete to the best of my knowledge and belief. l agree to provide under the penalties of perjury supporting evidence and provide updates in case any of the aforementioned information changes. Incase Dabari invest has any reason to believe that the disclosed informations is incorrect, the bank reserves the right to take subtable action against me.</p>

            <p className='font-bold'> By signing below, the Client confirm and agrees that (notwithstanding any other provision in the Terms and Conditions):</p>

            <p > 1. The Gent wil provide adational information or documents that the Bankneeds from the Ghent and that the Chent waves any cenfidentialturights abolicable under data crotectin bankino secrecu or soniar aas n resoect of alliniormation the bank holds or obtains from the chent which the Bank needs to disclose to comply with is obligations.</p>

            <p >{`2. The Client permits disclosure of such information to the tax authorities referred to above and to the tax authority's agents or sub-contractors engaged for the purpose of centralzing the processing of Client information in another country`}</p>
            <p >3. if the Client does not provide the Bank with information or documents the Bank needs, the Bank may withhold a proportion of the available balance, including profit or internet, paid to the client as required by any tax authority, close the account and/ or terminate the banking facilities of a the Client or transfer the account and/ or banking facilities to an affiliate of the bank.
            </p>
            <p >4. if the client asks the Bank to make a payment to an account based at a financial institution which does not participate or comply with the relevant tax legislation, the Bank maybe required, and the Client authorizes the Bank, to withhold certain amounts from the paiement and the Bank will inform the cliente if this the case. </p>
            <p >{`5. The bank may transfer the client's data to another country or countries for processing by and on behalf of the bank and use agents sub-contractors to process the client's data to comply with the Bank's obligations.`} </p>
            <p >
                6. The Bank will not be liable to the Client for any loss the Client may suffer as a result of complying with legislation or agreements with tax authorities in accordance with this provision unless that loss is caused by the Banks gross negligence willful default or fraud as may be finally judicially determined

            </p>
            <p >{`7. The client will indemnify the bank against any all loss or damages incurred as a result of the client's breach or non-compliance with these terms and conditions or any representation by the client of information provided to the bank and


`} </p>
            <p > {`8. The Client's consent on the above mentioned arrangements will override any contradictory terms or consent provided by the client under any other agreement with the bank, whether before or after the date of signing these Terms and Conditions, not wit standing any clause governing the variation of an earlier agreement with the bank.`}</p>



        </div>
    )
}
