import React from "react";
import GetStarted from "../../components/getStarted";

export default function GetStartedPage() {
  return <GetStarted />;
}
